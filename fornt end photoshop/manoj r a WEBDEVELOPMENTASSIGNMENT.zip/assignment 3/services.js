const searchInput = document.querySelector('.search-box-input');
const searchButton = document.querySelector('.search-box-button');
const searchResultsContainer = document.querySelector('.search-results-container');

searchButton.addEventListener('click', () => {
  const searchTerm = searchInput.value.toLowerCase().trim(); // Sanitize input

  if (searchTerm) {
    const filteredServices = [ /* Your service data with names and descriptions */ ]
      .filter(service => service.name.toLowerCase().includes(searchTerm) || service.description.toLowerCase().includes(searchTerm));

    if (filteredServices.length > 0) {
      searchResultsContainer.innerHTML = ''; // Clear previous results

      const heading = document.createElement('h3');
      heading.textContent = `Search results for "${searchTerm}":`;
      searchResultsContainer.appendChild(heading);

      filteredServices.forEach(service => {
        const resultDiv = document.createElement('div');
        resultDiv.classList.add('search-results');

        const resultHeading = document.createElement('h4');
        resultHeading.textContent = service.name;
        resultDiv.appendChild(resultHeading);

        const resultDescription = document.createElement('p');
        resultDescription.textContent = service.description;
        resultDiv.appendChild(resultDescription);

        searchResultsContainer.appendChild(resultDiv);
      });

      searchResultsContainer.style.display = 'block'; // Show results
    } else {
      searchResultsContainer.innerHTML = '<p>No results found.</p>';
      searchResultsContainer.style.display = 'block';
    }
  } else {
    searchResultsContainer.style.display = 'none'; // Hide results if search term is empty
  }
});
